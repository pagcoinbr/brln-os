package log

import "testing"

func Test_Log(t *testing.T) {
	Debugf("gude \n", nil)
}
