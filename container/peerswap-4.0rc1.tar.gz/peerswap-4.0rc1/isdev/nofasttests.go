//go:build !fast_test
// +build !fast_test

package isdev

func FastTests() bool { return false }
