# **ThunderHub - Lightning Node Manager**

**Documentation has moved!** Find the documentation [here](http://docs.thunderhub.io/).
