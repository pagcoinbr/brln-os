# States

- [States](#states)
  - [Swap-in Sender](#swap-in-sender)
  - [Swap-in Receiver](#swap-in-receiver)
  - [Swap-out Sender](#swap-out-sender)
  - [Swap-out Receiver](#swap-out-receiver)

## Swap-in Sender

![swap-in-sender](img/swap-in-sender-states.png)

## Swap-in Receiver

![swap-in-receiver](img/swap-in-receiver-states.png)

## Swap-out Sender

![swap-out-sender](img/swap-out-sender-states.png)

## Swap-out Receiver

![swap-out-receiver](img/swap-out-receiver-states.png)
