export const appConstants = {
  cookieName: 'Thub-Auth',
  lnMarketsAuth: 'LnMarkets-Auth',
  tokenCookieName: 'Tbase-Auth',
  ambossCookieName: 'Amboss-Auth',
};
