//go:build dev
// +build dev

package isdev

func IsDev() bool { return true }
