from django.apps import AppConfig


class GuiConfig(AppConfig):
    name = 'gui'
