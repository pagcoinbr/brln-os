import { gql } from '@apollo/client';

export const LOGIN_AMBOSS = gql`
  mutation LoginAmboss {
    loginAmboss
  }
`;
