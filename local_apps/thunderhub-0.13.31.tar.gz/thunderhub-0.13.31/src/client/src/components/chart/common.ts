export const COMMON_CHART_STYLES = {
  tooltip: {
    backgroundColor: 'black',
    borderColor: 'black',
    textStyle: {
      color: 'white',
    },
  },
};
