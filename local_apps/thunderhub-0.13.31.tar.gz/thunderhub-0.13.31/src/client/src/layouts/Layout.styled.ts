import styled from 'styled-components';

export const PageWrapper = styled.div`
  position: relative;
  min-height: 100vh;
`;

export const HeaderBodyWrapper = styled.div`
  padding-bottom: 120px;
`;
